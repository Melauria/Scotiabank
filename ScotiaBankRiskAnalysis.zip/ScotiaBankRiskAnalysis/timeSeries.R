###############################################################################
################# using time series to predict future X's #####################
###############################################################################

## seasonal exponential smoothing
# ccorp
# rmse = 0.2965195
training = ccorp.ts[1:68]
holdout = ccorp.ts[69:80]

training.ts = ts(training, frequency = 4)
holdout.ts = ts(holdout, frequency = 4)
seasonalfit = HoltWinters(training.ts, seasonal = "additive")
print(seasonalfit)
alpha=seasonalfit$alpha 
beta=seasonalfit$beta 
gamma=seasonalfit$gamma 
lev = seasonalfit$coef[1]
tre = seasonalfit$coef[2]
sea = seasonalfit$coef[3:6]
n = length(holdout.ts)
sse <- 0
fc <- lev+tre+sea[1]
zt <- holdout.ts[1]
newv <- fc
fcerror <- zt-fc
sse <- sse + fcerror^2
vprev <- lev
bprev <- tre
for (i in 2:n){
  index = (i-1)%%4
  if (index == 0){
    index = 4
  }
  vnew <- alpha*(holdout.ts[i-1]-sea[index])+(1-alpha)*(vprev+bprev)
  bnew = beta*(vnew-vprev)+(1-beta)*bprev
  snew = gamma*(holdout.ts[i-1]-vnew)+(1-gamma)*sea[index]
  index1 = i%%4
  if (index1 == 0){
    index1 = 4
  }
  fc <- vnew+bnew+sea[index1]
  zt <- holdout.ts[i]
  fcerror <- zt-fc
  sse <- sse + fcerror^2
  vprev = vnew
  bprev = bnew
  sea[index] = snew
}
rmse = sqrt(sse/n)
rmse

acf(training,type="correlation",plot=T)
pacf(training,plot=T)

# AR(3)
# rmse = 0.5219937
ar3 = arima(training.ts, order = c(3,0,0),include.mean = T, method = "CSS")
ar3
mu = ar3$coef[4]
co = ar3$coef[1:3]
y = c(training.ts[38:40],holdout.ts)
y = y-mu
mse = 0
n = length(holdout.ts)
for (i in 1:n){
  u = cbind(y[i+2],y[i+1],y[i])
  fc = mu + co%*%t(u)
  zt = holdout[i]
  fcerror = zt-fc
  mse = mse+fcerror^2
}
rmse = sqrt(mse/n)
rmse
