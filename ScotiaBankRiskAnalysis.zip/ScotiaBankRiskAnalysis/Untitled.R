install.packages("corrplot")

# import dataset
FV_ccorp = read.delim("ccorp.txt",sep = " ",header = T)
Canadian = read.delim("cmacro.txt",sep = " ",header = T)
crs = read.delim("crs.txt",sep = " ",header = T)
US = read.delim("umacro.txt",sep = " ",header = T)
vix = read.delim("vix.txt",sep = " ",header = T)
wcommod = read.delim("wcommod.txt",sep = " ",header = T)

# import response variable datasets
ir127 = read.table("ir127yr.txt", header = T)
ir164 = read.table("ir164yr.txt", header = T)
ir247 = read.table("ir247yr.txt", header = T)
ir302 = read.table("ir302yr.txt", header = T)

ir127 = data.frame(ir127[46:2703,c(1,3,5,7,9,11,13,15,17,19,21,23)])
ir164 = data.frame(ir164[46:2702,c(1,3,5,7,9,11,13,15,17,19,21,23)])
ir247 = data.frame(ir247[46:3140,c(1,3,5,7,9,11,13,15,17,19,21,23)]) 
ir302 = data.frame(ir302[46:3140,c(1,3,5,7,9,11,13,15,17,19,21,23)])

colnames_ = c("date", "yr1", "yr2", 'yr3', 'yr4','yr5', 'yr7','yr10','yr12','yr15','yr20','yr30')
colnames(ir127) = colnames_
colnames(ir164) = colnames_
colnames(ir247) = colnames_
colnames(ir302) = colnames_

## visualization
muturity = c(1,2,3,4,5,7,10,12,15,20,30)
as.numeric(unlist(muturity))
par(mfrow=c(3,3))

# ir127 2008
ir127_2008_02 = subset(ir127,date>=20080207 & date <=20080219)
for (i in 1:9){
  plot(muturity, ir127_2008_02[i,2:12],ylab = "rate", main = ir127_2008_02[i,1])
}
ir127_2008_05 = subset(ir127,date>=20080520 & date <=20080531)
for (i in 1:9){
  plot(muturity, ir127_2008_05[i,2:12],ylab = "rate", main = ir127_2008_05[i,1])
}
ir127_2008_08 = subset(ir127,date>=20080801 & date <=20080813)
for (i in 1:9){
  plot(muturity, ir127_2008_08[i,2:12],ylab = "rate", main = ir127_2008_08[i,1])
}
ir127_2008_11 = subset(ir127,date>=20081113 & date <=20081125)
for (i in 1:9){
  plot(muturity, ir127_2008_11[i,2:12],ylab = "rate", main = ir127_2008_11[i,1])
}

# ir127 2014
ir127_2014_02 = subset(ir127,date>=20140207 & date <=20140219)
for (i in 1:9){
  plot(muturity, ir127_2014_02[i,2:12],ylab = "rate", main = ir127_2014_02[i,1])
}
ir127_2014_05 = subset(ir127,date>=20140520 & date <=20140531)
for (i in 1:9){
  plot(muturity, ir127_2014_05[i,2:12],ylab = "rate", main = ir127_2014_05[i,1])
}
ir127_2014_08 = subset(ir127,date>=20140801 & date <=20140813)
for (i in 1:9){
  plot(muturity, ir127_2014_08[i,2:12],ylab = "rate", main = ir127_2014_08[i,1])
}
ir127_2014_11 = subset(ir127,date>=20141113 & date <=20141125)
for (i in 1:9){
  plot(muturity, ir127_2014_11[i,2:12],ylab = "rate", main = ir127_2014_11[i,1])
}


# ir127 2005
ir127_2005 = subset(ir127,date>=20050216 & date <=20051231)
for (i in 1:9){
  plot(muturity, ir127_2005[i,2:12],ylab = "rate", main = ir127_2005[i,1])
}

# ir127 2006
ir127_2006 = subset(ir127,date>=20060526 & date <=20061120)
for (i in 1:9){
  plot(muturity, ir127_2006[i,2:12],ylab = "rate", main = ir127_2006[i,1])
}


# polynomial fit ✘
y = as.numeric(unlist(ir127_2008_05[1,2:12]))
muturity2 = muturity^2
fit = lm(y ~ muturity + muturity2)
coef(fit)
interval = seq(0, 30, 0.1)
predictedcounts <- predict(fit,list(muturity = interval, muturity2 = interval^2))
plot(muturity, y)
lines(interval, predictedcounts, col = "darkgreen", lwd = 3,ylim = c(0:0.07))

y = as.numeric(unlist(ir127_2005[1,2:12]))
muturity2 = muturity^2
fit = lm(y ~ muturity + muturity2)
coef(fit)
interval = seq(0, 30, 0.1)
predictedcounts <- predict(fit,list(muturity = interval, muturity2 = interval^2))
plot(muturity, y)
lines(interval, predictedcounts, col = "darkgreen", lwd = 3,ylim = c(0:0.07))

y = as.numeric(unlist(ir127_2014_11[5,2:12]))
muturity2 = muturity^2
fit = lm(y ~ muturity + muturity2)
coef(fit)
interval = seq(0, 30, 0.1)
predictedcounts <- predict(fit,list(muturity = interval, muturity2 = interval^2))
plot(muturity, y)
lines(interval, predictedcounts, col = "darkgreen", lwd = 3,ylim = c(0:0.07))

## plots
par(mfrow=c(2,2))
ccorp.ts = ts(data = FV_ccorp$ccorp, start = c(1997,1), end = c(2016,4), frequency = 4)
#plot(FV_ccorp.ts, main = "BFV CAD Canada Corporate monthly from 1996-12 to 2017-06")
crs.ts = ts(data = crs$crs, start = c(2005,1), end = c(2016,4), frequency = 4)
#plot(crs.ts, main = "Retail sales, volume index from 1997-12 to 2017-09")
vix.ts = ts(data = vix$vix, start = c(2005,1), end = c(2016,4), frequency = 4)
#plot(vix.ts, main = "CBOE Market Volatility Index from 1993-12 to 2017-09")

US.ts = ts(US[,2:17], start = c(2005,1), end = c(2016,4),frequency = 4)
#plot(US.ts[,1:8], main = "US[,1:8] from 1993-12 to 2017-09")
#plot(US.ts[,9:16], main = "US[,9:16] from 1993-12 to 2017-09")

Canadian.ts<-ts(Canadian[,2:19],start = c(2005,1), end = c(2016,4),frequency=4)
#plot(Canadian.ts[,1:6],main="Canadian[,1:6] from 1993-12 to 2017-9")
#plot(Canadian.ts[,7:12],main="Canadian[,7:12] from 1993-12 to 2017-9")
#plot(Canadian.ts[,13:18],main="Canadian[,13:18] from 1993-12 to 2017-9")

wcommod.ts = ts(wcommod[,2:8], start = c(2005,1), end = c(2016,4), frequency = 4)
#plot(wcommod.ts, main = "World GDP and commodity prices from 1993-12 to 2017-09")

# trim data
# Canadian.ex = Canadian.ts[,5:18]
# US.ex = US.ts[,4:16]

# correlarion
# wcommod.cor = cor(wcommod.ts, use = "complete.obs")
# corrplot(wcommod.cor, method="number", type = "upper")
# Canadian.cor = cor(Canadian.ex, use = "complete.obs")
# corrplot(Canadian.cor, method="number", type = "upper")
# US.cor = cor(US.ex, use = "complete.obs")
# corrplot(US.cor, method="number", type = "upper")

###############################################################################
################################## Fit model ##################################
###############################################################################

# get variables
FV_ccorp = read.delim("ccorp.txt",sep = " ",header = T)
Canadian = read.delim("cmacro.txt",sep = " ",header = T)
crs = read.delim("crs.txt",sep = " ",header = T)
US = read.delim("umacro.txt",sep = " ",header = T)
vix = read.delim("vix.txt",sep = " ",header = T)
wcommod = read.delim("wcommod.txt",sep = " ",header = T)

y = read.csv("summary.csv", header = T)
y127 = y[1:50,4]
y164 = y[51:100,]
y247 = y[101:150,]
y302 = y[151:200,]
ccorp.fit = FV_ccorp$ccorp[34:83]
crs.fit = crs$crs[30:79]
vix.fit = vix$vix[46:95]
US = select(US,-c(utbill,ugbond05,ugbond10,upop))
Canadian = select(Canadian,-c(ctbill,cgbond01,cgbond05,cgbond10,cpop))
for (i in 95:46) {
  wcommod$wrgdp[i]=(wcommod$wrgdp[i]-wcommod$wrgdp[i-4])/wcommod$wrgdp[i-4]*100
  wcommod$woil[i]=(wcommod$woil[i]-wcommod$woil[i-1])/wcommod$woil[i-1]
  wcommod$wgold[i]=(wcommod$wgold[i]-wcommod$wgold[i-1])/wcommod$wgold[i-1]
  Canadian$ccs[i]=(Canadian$ccs[i]-Canadian$ccs[i-1])/Canadian$ccs[i-1]
  Canadian$cngdp[i]=(Canadian$cngdp[i]-Canadian$cngdp[i-4])/Canadian$cngdp[i-4]*100
  Canadian$cgdebt[i]=(Canadian$cgdebt[i]-Canadian$cgdebt[i-1])/Canadian$cgdebt[i-1]
  Canadian$chst[i]=(Canadian$chst[i]-Canadian$chst[i-1])/Canadian$chst[i-1]
  Canadian$cgrev[i]=(Canadian$cgrev[i]-Canadian$cgrev[i-1])/Canadian$cgrev[i-1]
  US$ungdp[i]=(US$ungdp[i]-US$ungdp[i-4])/US$ungdp[i-4]*100
  US$ugdebt[i]=(US$ugdebt[i]-US$ugdebt[i-1])/US$ugdebt[i-1]
  US$ugrev[i]=(US$ugrev[i]-US$ugrev[i-1])/US$ugrev[i-1]
  US$uhst[i]=(US$uhst[i]-US$uhst[i-1])/US$uhst[i-1]
}
Canadian.fit = Canadian[46:95,2:14]
US.fit = US[46:95,2:13]
wcommod.fit = wcommod[46:95,2:8]
X = data.frame(ccorp.fit, crs.fit, vix.fit, US.fit, Canadian.fit, wcommod.fit)

######################### linear with all variables #########################
### y127
set.seed(1234)
inx = sample(1:50, 40, replace=FALSE)
y127_new = y[1:50,]
X_training = X[inx,]
X_holdout = X[-inx,]
# check residual
# lmfit = lm(y127_new[,4]~., data = X)
# par(mfrow=c(3,3))
# y127_res = resid(lmfit)
# for (i in 1:32){
#   plot(X[,i],y127_res,xlab=colnames(X[i]),ylab="residual")
# }
# 
# lmfit = lm(y127_new[,5]~., data = X)
# par(mfrow=c(3,3))
# y127_res = resid(lmfit)
# for (i in 1:32){
#   plot(X[,i],y127_res,xlab=colnames(X[i]),ylab="residual")
# }
# average
# rmse = 0.007279337
y127_training = y127_new[inx,4]
y127_holdout = y127_new[-inx,4]
lmfit = lm(y127_training~., data = X_training)
lmfit.pred = predict(lmfit, X_holdout)
rmse =sqrt(sum((y127_holdout - lmfit.pred)^2)/10)
rmse
plot(lmfit.pred,ylim = c(-0.01,0.04))
points(y127_holdout,col='red')
# par(mfrow=c(3,3))
# y127_res = resid(lmfit)
# for (i in 1:32){
#   plot(X_training[,i],y127_res,xlab=colnames(X_training[i]),ylab="residual")
# }
# median
# rmse = 0.004933681
# y127_training = y127_new[inx,5]
# y127_holdout = y127_new[-inx,5]
# lmfit = lm(y127_training~., data = X_training)
# lmfit.pred = predict(lmfit, X_holdout)
# rmse =sqrt(sum((y127_holdout - lmfit.pred)^2)/10)
# rmse
# plot(lmfit.pred)
# points(y127_holdout,col='red')

### y164
set.seed(1234)
inx = sample(1:50, 40, replace=FALSE)
y164_new = y[51:100,]
X_training = X[inx,]
X_holdout = X[-inx,]
# average
# rmse = 0.005912798
y164_training = y164_new[inx,4]
y164_holdout = y164_new[-inx,4]
lmfit = lm(y164_training~., data = X_training)
lmfit.pred = predict(lmfit, X_holdout)
rmse =sqrt(sum((y164_holdout - lmfit.pred)^2)/10)
rmse
plot(lmfit.pred,ylim = c(-0.01,0.04))
points(y164_holdout,col='red')
# median
# rmse = 0.002867142
# y164_training = y164_new[inx,5]
# y164_holdout = y164_new[-inx,5]
# lmfit = lm(y164_training~., data = X_training)
# lmfit.pred = predict(lmfit, X_holdout)
# rmse =sqrt(sum((y164_holdout - lmfit.pred)^2)/10)
# rmse
# plot(lmfit.pred)
# points(y164_holdout,col='red')

### y247
set.seed(1234)
inx = sample(1:50, 40, replace=FALSE)
y247_new = y[101:150,]
X_training = X[inx,]
X_holdout = X[-inx,]
# average
# rmse = 0.006688651
y247_training = y247_new[inx,4]
y247_holdout = y247_new[-inx,4]
lmfit = lm(y247_training~., data = X_training)
lmfit.pred = predict(lmfit, X_holdout)
rmse =sqrt(sum((y247_holdout - lmfit.pred)^2)/10)
rmse
plot(lmfit.pred,ylim = c(-0.01,0.04))
points(y247_holdout,col='red')
# median
# rmse = 0.006134168
# y247_training = y247_new[inx,5]
# y247_holdout = y247_new[-inx,5]
# lmfit = lm(y247_training~., data = X_training)
# lmfit.pred = predict(lmfit, X_holdout)
# rmse =sqrt(sum((y247_holdout - lmfit.pred)^2)/10)
# rmse

### y302
set.seed(1234)
inx = sample(1:50, 40, replace=FALSE)
y302_new = y[101:150,]
X_training = X[inx,]
X_holdout = X[-inx,]
# average
# rmse = 0.006688651
y302_training = y302_new[inx,4]
y302_holdout = y302_new[-inx,4]
lmfit = lm(y302_training~., data = X_training)
lmfit.pred = predict(lmfit, X_holdout)
rmse =sqrt(sum((y302_holdout - lmfit.pred)^2)/10)
rmse
plot(lmfit.pred,ylim = c(-0.01,0.04))
points(y302_holdout,col='red')
# median
# rmse = 0.006134168
# y302_training = y302_new[inx,5]
# y302_holdout = y302_new[-inx,5]
# lmfit = lm(y302_training~., data = X_training)
# lmfit.pred = predict(lmfit, X_holdout)
# rmse =sqrt(sum((y302_holdout - lmfit.pred)^2)/10)
# rmse

####################### linear with selected variables ########################

### y127
set.seed(1234)
inx = sample(1:50, 40, replace=FALSE)
y127_new = y[1:50,]
X_127 = select(X,c(ccorp.fit, crs.fit, vix.fit, urgdp, ucpi, ugbal, uggip, ucprof, uhpi, ucrepi, 
                   ugdebt, uurate, crgdp, ccpi, cgbal, cggip, ccprof, chst, ceempl, 
                   wrgdp, woil, wcopp, walum, wgas, wfood))
X_training = X_127[inx,]
X_holdout = X_127[-inx,]
# average
# rmse = 0.002871632
y127_training = y127_new[inx,4]
y127_holdout = y127_new[-inx,4]
lmfit = lm(y127_training~., data = X_training)
lmfit.pred = predict(lmfit, X_holdout)
rmse =sqrt(sum((y127_holdout - lmfit.pred)^2)/10)
rmse
plot(lmfit.pred,ylim = c(-0.01,0.04))
points(y127_holdout,col='red')


### y164
set.seed(1234)
inx = sample(1:50, 40, replace=FALSE)
y164_new = y[51:100,]
X_164 = select(X,c(ccorp.fit, crs.fit, vix.fit, uggip, ucprof, uhpi, uurate, crgdp, ccpi, 
                   crlend, cggip, ccprof, chst, curate, ceempl, woil, walum, wgas, wfood))
X_training = X_164[inx,]
X_holdout = X_164[-inx,]
# average
# rmse = 0.00287209
y164_training = y164_new[inx,4]
y164_holdout = y164_new[-inx,4]
lmfit = lm(y164_training~., data = X_training)
lmfit.pred = predict(lmfit, X_holdout)
rmse =sqrt(sum((y164_holdout - lmfit.pred)^2)/10)
rmse
plot(lmfit.pred,ylim = c(-0.01,0.04))
points(y164_holdout,col='red')


### y247
set.seed(1234)
inx = sample(1:50, 40, replace=FALSE)
y247_new = y[101:150,]
X_247 = subset(X,select=c(ccorp.fit, crs.fit, vix.fit, urgdp, uggip, ucprof, uhpi, uhst, 
                          ucrepi, ugdebt, uurate, ccpi, crlend, cggip, ccprof, 
                          curate, ceempl, woil, wcopp, walum, wgas, wfood))
X_training = X_247[inx,]
X_holdout = X_247[-inx,]
# average
# rmse = 0.00258535
y247_training = y247_new[inx,4]
y247_holdout = y247_new[-inx,4]
lmfit = lm(y247_training~., data = X_training)
lmfit.pred = predict(lmfit, X_holdout)
rmse =sqrt(sum((y247_holdout - lmfit.pred)^2)/10)
rmse
plot(lmfit.pred,ylim = c(-0.01,0.04))
points(y247_holdout,col='red')


### y302
set.seed(1234)
inx = sample(1:50, 40, replace=FALSE)
y302_new = y[101:150,]
X_302 = select(X,c(ccorp.fit,crs.fit, vix.fit, ucpi, uggip, uhpi, uhst, ucrepi, 
                   ugdebt, uurate, crgdp, ccpi, cgbal, cggip, ccprof, 
                   woil, wcopp, walum, wgas))
X_training = X_302[inx,]
X_holdout = X_302[-inx,]
# average
# rmse = 0.002235479
y302_training = y302_new[inx,4]
y302_holdout = y302_new[-inx,4]
lmfit = lm(y302_training~., data = X_training)
lmfit.pred = predict(lmfit, X_holdout)
rmse =sqrt(sum((y302_holdout - lmfit.pred)^2)/10)
rmse
plot(lmfit.pred, ylim = c(-0.01,0.04))
points(y302_holdout,col='red')


